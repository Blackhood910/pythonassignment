def load_values(filename):
    """
   this Function takes a file as an argument and create a dictionary for the values in the file 
    """
    values = {}
    with open(filename, "r") as f:
        for line in f:
            letter, value = line.split()
            values[letter] = int(value)
    return values

def calculate_score(second_letter,third_letter,second_letter_pos , third_letter_pos, word, letter_values):
    """
    This Functions is used to calculate the scores for the abbreviation provided to it.
    it takes second letter and third letter from abbreviations along with their positions
    it also takes word that belongs to the abreviation and the value of the letter from values file as parameter
    """
    
    
    second_letter_score=0
    third_letter_score=0
    last_pos=(len(word)-1)
    is_compund= False
    # This is use to check if the word is a compound word or not by looking at the identifier i.e. "-"
    for i in range( 1, last_pos) :
        if word [i] == '-':
            is_compund=True
        
        
    if is_compund == True :
        hyphen_positions = [i for i, char in enumerate(word) if char == '-']   
        number_of_hyphen = len(hyphen_positions)
        snd_let_is_2_word=False # tells that 2nd letter belongs to the first letter of the word
        thd_let_is_2_word = False #  tells that 3nd letter belongs to the first letter of the word
        second_word_index= hyphen_positions[0]+1 
        first_word_last_index = hyphen_positions[0]-1
         
        # this mean that the compound word is more than 2 word 
        # this part calculate the 2nd letter score
        if number_of_hyphen > 1 :
            third_word_index= hyphen_positions[1]+1
            second_word_last_index= hyphen_positions[1]-1
            snd_let_is_3_word=False
            thd_let_is_3_word = False
           
            if second_letter_pos == second_word_index :
               
                if second_letter == word[second_word_index]:
                    second_letter_score=0
                    snd_let_is_2_word=True

            if second_letter_pos == third_word_index :
                
                if second_letter == word[third_word_index]:
                    second_letter_score=0
                    snd_let_is_3_word=True                      
            if second_letter_pos == first_word_last_index or second_letter_pos == second_word_last_index:
                if second_letter == 'E':
                    second_letter_score=20
                else :
                    second_letter_score=5   
                                         
            if second_letter_score == 0 and not snd_let_is_2_word and not snd_let_is_3_word:
                
                if second_letter_pos == 1 or second_letter_pos== second_word_index + 1 or second_letter_pos== third_word_index + 1 :
                   
                    second_letter_score=1
                
                if second_letter_pos == 2 or second_letter_pos == second_word_index + 2 or second_letter_pos== third_word_index + 2 :
                    
                    second_letter_score=2
            
                elif second_letter_pos> 2 and second_letter_pos <second_word_index or second_letter_pos > second_word_index+2 and second_letter_pos< third_word_index or second_letter_pos > third_word_index + 2 :
                    
                    second_letter_score=3
                
                second_letter_score= second_letter_score + letter_values.get(second_letter, 0) 
                
           #this part calculate the 3rd letter score
                
            if third_letter_pos == second_word_index  and not snd_let_is_2_word and not snd_let_is_3_word :
                if third_letter == word[second_word_index]:
                    third_letter_score=0
                    thd_let_is_2_word=True
                    
            if third_letter_pos == third_word_index and not snd_let_is_3_word:
                if third_letter == word[third_word_index]:
                    third_letter_score=0
                    thd_let_is_3_word=True
                    
            if third_letter_pos == first_word_last_index or third_letter_pos== second_word_last_index or third_letter_pos== last_pos:
                
                if third_letter == 'E':
                    third_letter_score=20
                else :
                    third_letter_score=5
                
                        
            elif third_letter_score==0 and not thd_let_is_2_word and not thd_let_is_3_word:
                if third_letter_pos == 1 or third_letter_pos== second_word_index + 1 or third_letter_pos== third_word_index + 1 :
                    third_letter_score=1
                
                if third_letter_pos == 2 or third_letter_pos == second_word_index + 2 or third_letter_pos == third_word_index + 2 :
                    third_letter_score=2
                elif third_letter_pos> 2 and third_letter_pos <second_word_index or third_letter_pos > second_word_index+2 and third_letter_pos< third_word_index or third_letter_pos > third_word_index + 2 :
                    third_letter_score=3
                
                third_letter_score= third_letter_score + letter_values.get(third_letter, 0)    
                
           
        # this means that the compound word is of 2 words
        elif number_of_hyphen == 1: 
            
            # this part calculate the 2nd letter score
            if second_letter_pos == second_word_index :
                if second_letter == word[second_word_index]:
                    second_letter_score=0
                    snd_let_is_2_word=True
                                       
            if second_letter_pos == first_word_last_index:
                if second_letter == 'E':
                    second_letter_score=20
                else :
                    second_letter_score=5                        
            elif second_letter_score==0 and not snd_let_is_2_word:
                if second_letter_pos == 1 or second_letter_pos== second_word_index + 1 :
                 
                    second_letter_score=1
                
                if second_letter_pos == 2 or second_letter_pos == second_word_index + 2 :
                    second_letter_score=2
            
                elif second_letter_pos> 2 and second_letter_pos <second_word_index or second_letter_pos > second_word_index+2:
                 
                    second_letter_score=3
                second_letter_score= second_letter_score + letter_values.get(second_letter, 0) 
            
            
            #this part calculate the 3nd letter score
                
            if third_letter_pos == second_word_index and not snd_let_is_2_word:
                if third_letter == word[second_word_index]:
                    thd_let_is_2_word=True
                    
                    
            if third_letter_pos == first_word_last_index  or third_letter_pos== last_pos:
                
                if third_letter == 'E':
                    third_letter_score=20
                else :
                    third_letter_score=5
                
                        
            elif third_letter_score==0 and not thd_let_is_2_word:
                if third_letter_pos == 1 or third_letter_pos== second_word_index + 1 :
                    third_letter_score=1
                
                if third_letter_pos == 2 or third_letter_pos == second_word_index + 2  :
                
                    third_letter_score=2
                elif third_letter_pos> 2 and third_letter_pos <second_word_index or third_letter_pos > second_word_index+2:
                    third_letter_score=3
                
                third_letter_score= third_letter_score + letter_values.get(third_letter, 0)
               
                
    # this mean that the word is not a compound word 
    elif not is_compund :
       # here we check if the 3rd and 2nd letter in the abbreviations
        if  third_letter_pos == last_pos :
            if third_letter== 'E':
                third_letter_score=20
            else :
                third_letter_score=5
                
               
        if second_letter_pos == 1 :
            second_letter_score=1
        elif second_letter_pos == 2 :
            second_letter_score = 2
        else :
            second_letter_score=3
        second_letter_score= second_letter_score + letter_values.get(second_letter, 0)
        if third_letter_score == 0:    
            if third_letter_pos == 1 :
                third_letter_score=1
            elif third_letter_pos == 2 :
                third_letter_score = 2
            else :
                third_letter_score=3
            
            third_letter_score= third_letter_score + letter_values.get(third_letter, 0)       

    return second_letter_score+ third_letter_score
     

def generate_abbreviations(name, letter_values):
    """
    This Function is use to generate the abbreviations from the words in the file alongs with their scores
    This functions takes name from file and letter values from values file as parameter
    """
    words = [word.strip("',\"") for word in name.upper().split()] # this check if the word has any commas or spaces and remove them and create a list of words
    abbreviations = []
    
    """
    This loops iterate the words after the first letter in the word and make a combinations of abreviations where 2 letter is always before 
    the 3 rd letter
    """
    for word in words:
        if word:
            first_letter = word[0]
            for i in range(1, len(word) - 1):
                second_letter = word[i]
                for j in range(i + 1, len(word)):
                    third_letter = word[j]
                    abbreviation = f"{first_letter}{second_letter}{third_letter}"
                    
                    # this ensure that only the abbreviations with alphabeds letter are consider
                    
                    if abbreviation.isalpha():
                        score = calculate_score(second_letter,third_letter,i,j,word, letter_values )
                        abbreviations.append((abbreviation, score))
                        
     

    """
    Here we are iterating through the abrevitions made and making sure that if there are any duplicated abbreviations in the lsit then this 
    is first comparing them all and then only select the one with lowest score and eliminate the rest
    """                   
                        
    unique_abbreviations = []

    for i, (abbreviation_i, score_i) in enumerate(abbreviations):
        found_duplicate = False
        min_score = score_i

        for j, (abbreviation_j, score_j) in enumerate(abbreviations[i + 1:], start=i + 1):
            if abbreviation_i == abbreviation_j:
                found_duplicate = True
                min_score = min(min_score, score_j)

        if not found_duplicate:
            unique_abbreviations.append((abbreviation_i, score_i))
        else:
            # Replace all occurrences of the duplicate abbreviation with the one with the lowest score
            for k, (abbreviation_k, score_k) in enumerate(abbreviations):
                if abbreviation_k == abbreviation_i:
                    abbreviations[k] = (abbreviation_i, min_score)

    # Filter out duplicates
    print(unique_abbreviations)
    unique_abbreviations = list(set(unique_abbreviations))
    

    return unique_abbreviations
   
def find_best_abbreviations(abbreviations):
    """
    This Functions is use to remove any abreviations value that is present in more than one word in the abbreviation list
    """
    unique_abbreviations = {}
    
    # Here we are converting the abbrevition from list to a dictionary structure and the key is the abbreviation
    for abbreviation, score in abbreviations:
        unique_abbreviations[abbreviation] = (abbreviation, score)
    # this call the fucntion remove item by key which then gives dictionary with unique abbreviations for all the words in the list.
    best_abbreviations={}
    best_abbreviations = remove_items_by_keys(unique_abbreviations,abb_dup)
    
    return best_abbreviations
  
  
def remove_items_by_keys(input_dict, keys_to_remove):
    """
    This is a function that only returns the key in input_dictionary if it is not present in the list of keys
    """
    return {key: value for key, value in input_dict.items() if key not in keys_to_remove}


def find_duplicates(my_list):
    """
    This function take a list of abbreviations and find the duplicate abbreviations in them and return a list of duplicated abbreviations
    """
    seen_values = []
    duplicates = []

    for value in my_list:
        if value in seen_values:
            duplicates.append(value)
        else:
            seen_values.append(value)

    return duplicates


    """
    This the main part or the main function of the code where load the input file of the name and write the output abbriviations for each word 
    along with their score 
    """
input_filename_input = input("Enter the input file name (.txt): ")    
input_filename = "C:\\Users\\hasee\\OneDrive\\Desktop\\python assignment\\" +input_filename_input  # Change this to the actual input filename
output_filename = input("Enter your surname: ").lower() + '_' + input_filename_input[:-4] + '_abbrevs.txt'  # Change this to the desired output filename
letter_values = load_values("C:\\Users\\hasee\\OneDrive\\Desktop\\python assignment\\values.txt")
abb_dup = [] # this is global list to hold all the abbriviations in the file
abb_name = []  # this is global list to hold all the duplicated abbriviations in the file
with open(input_filename, "r") as input_file, open(output_filename, "w") as output_file:
    for line in input_file:
        name = line.replace(" ", "-")    # here we are replacing all the " " with "-" so that it cound be used as a word identifier
        name= name.replace("'","") # here we are ignoring the ' in a word
        abbreviations = generate_abbreviations(name, letter_values) # contains the abbreviations of the names
        for i, (abbreviation_i, score_i) in enumerate(abbreviations):#  loading all the abbreviations in the list 
            abb_name.append(abbreviation_i)
        
        abb_dup=find_duplicates(abb_name) # finding the duplicates
        
        best_abbreviations = find_best_abbreviations(abbreviations )
        if best_abbreviations:
            min_key= min(best_abbreviations,key=lambda k: best_abbreviations[k][1]) # used to find the minimum abbrevition key of the name in the dictionary
            best_score = best_abbreviations[min_key] # use the key to find the min abbreviation score
            output_file.write(f"{name}\n{min_key} ({best_score})\n\n") # print the name of the word along with its abbreviation with the minimum score
        else:
            output_file.write(f"{name}\nNo acceptable abbreviation\n\n") # if there is no appropiate output to the input


